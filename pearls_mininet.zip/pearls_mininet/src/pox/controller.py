


# based on Part 2 of UWCSE's Project 3
# based on Lab 4 from UCSC's Networking Class
# which is based on of_tutorial by James McCauley

from pox.core import core
import pox.openflow.libopenflow_01 as of
from pox.lib.revent import *
from pox.lib.addresses import IPAddr
import pox.lib.packet as pkt
from pox.messenger import *

rules = [['10.0.0.01','10.0.0.05'],['10.0.0.20', '10.0.0.15']]

log = core.getLogger()
class Controller (object):
  """
  A Controller object is created for each switch that connects.
  A Connection object for that switch is passed to the __init__ function.
  """
  print (rules)
  def __init__ (self, connection):
    # Keep track of the connection to the switch so that we can
    # send it messages!
    self.connection = connection
    core.openflow.addListeners(self)
     # This binds our PacketIn event listener
    connection.addListeners(self)
    core.listen_to_dependencies(self)
  def _all_dependencies_met (self):
      # create messenger channel
      chat_channel = core.MessengerNexus.get_channel("controller")
      print ("m1")
      #core.messenger.addListener(MessageReceived, self.handle_chat)
      print("m2")
      def handle_chat (event, msg):
         print ("handle ")
         m = str(msg.get("msg"))
         if m == "close":
            log.debug("Close message received.")
            print ("closing")
         elif m =="newRule":
            rule = [msg.get("blockSRC"), msg.get("blockDEST")]
            rules.append(rule)
         elif m == "test":
            print ("test recieved")
      chat_channel.addListener(MessageReceived, handle_chat)
#add switch rules here
  def _handle_PacketIn (self, event):
    """
    Packets not handled by the router rules will be
    forwarded to this method to be handled by the controller
    """
    packet = event.parsed # This is the parsed packet data.
    if not packet.parsed:
      log.warning("Ignoring incomplete packet")
      return
    for rule in rules:
        block = of.ofp_match()
        block.dl_type = pkt.ethernet.IP_TYPE
        block.nw_src = IPAddr(rule[0])
        block.nw_dst = IPAddr(rule[1])
        flow_mod = of.ofp_flow_mod()
        flow_mod.match = block
        event.connection.send(flow_mod)

    packet_in = event.ofp # The actual ofp_packet_in message.
    print ("Unhandled packet :" + str(packet.dump()))
# setup event handler in pox
    #chat_channel.addListener(MessageReceived, handle_chat)

def launch ():
  """
  Starts the component
  """
  def start_switch (event):
     print ("start_switch")
     log.debug("Controlling %s" % (event.connection,))
     Controller(event.connection)
  core.openflow.addListenerByName("ConnectionUp", start_switch)