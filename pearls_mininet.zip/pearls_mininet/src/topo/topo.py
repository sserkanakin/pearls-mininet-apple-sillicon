from mininet.topo import Topo
from mininet.net import Mininet
from mininet.util import dumpNodeConnections
from mininet.cli import CLI
from mininet.node import Controller, RemoteController


class sample_topo(Topo):

    def __init__(self):
        Topo.__init__(self)
        # switches
        # 1
        s1 = self.addSwitch('s1')
        s11 = self.addSwitch('s11')
        s111 = self.addSwitch('s111')
        s112 = self.addSwitch('s112')
        s12 = self.addSwitch('s12')
        s121 = self.addSwitch('s121')
        s122 = self.addSwitch('s122')
        # 2
        s2 = self.addSwitch('s2')
        s21 = self.addSwitch('s21')
        s211 = self.addSwitch('s211')
        s212 = self.addSwitch('s212')
        s213 = self.addSwitch('s213')
        s22 = self.addSwitch('s22')
        s221 = self.addSwitch('s221')
        s222 = self.addSwitch('s222')

        # 3
        s3 = self.addSwitch('s3')
        s31 = self.addSwitch('s31')
        s311 = self.addSwitch('s311')
        # hosts
        h111 = self.addHost('H111', ip='10.0.0.1', mac='00:00:00:00:00:01')
        h112 = self.addHost('H112', ip='10.0.0.2', mac='00:00:00:00:00:02')
        h121_1 = self.addHost('H121.1', ip='10.0.0.3', mac='00:00:00:00:00:03')
        h121_2 = self.addHost('H121.2', ip='10.0.0.4', mac='00:00:00:00:00:04')
        h121_3 = self.addHost('H121.3', ip='10.0.0.5', mac='00:00:00:00:00:05')
        h122 = self.addHost('H122', ip='10.0.0.6', mac='00:00:00:00:00:06')

        h211_1 = self.addHost('H211.1', ip='10.0.0.7', mac='00:00:00:00:00:07')
        h211_2 = self.addHost('H211.2', ip='10.0.0.8', mac='00:00:00:00:00:08')
        h211_3 = self.addHost('H211.3', ip='10.0.0.9', mac='00:00:00:00:00:09')
        h211_4 = self.addHost('H211.4', ip='10.0.0.10', mac='00:00:00:00:00:10')
        h212_1 = self.addHost('H212.1', ip='10.0.0.11', mac='00:00:00:00:00:11')
        h212_2 = self.addHost('H212.2', ip='10.0.0.12', mac='00:00:00:00:00:12')
        h213_1 = self.addHost('H213.1', ip='10.0.0.13', mac='00:00:00:00:00:13')
        h213_2 = self.addHost('H213.2', ip='10.0.0.14', mac='00:00:00:00:00:14')
        h213_3 = self.addHost('H213.3', ip='10.0.0.15', mac='00:00:00:00:00:15')
        h221_1 = self.addHost('H221.1', ip='10.0.0.16', mac='00:00:00:00:00:16')
        h221_2 = self.addHost('H221.2', ip='10.0.0.17', mac='00:00:00:00:00:17')
        h222 = self.addHost('H222', ip='10.0.0.18', mac='00:00:00:00:00:18')

        h311_1 = self.addHost('H311.1', ip='10.0.0.19', mac='00:00:00:00:00:19')
        h311_2 = self.addHost('H311.2', ip='10.0.0.20', mac='00:00:00:00:00:20')
        h311_3 = self.addHost('H311.3', ip='10.0.0.21', mac='00:00:00:00:00:21')
        # links
        self.addLink(h111, s111)
        self.addLink(h112, s112)
        self.addLink(s111, s11)
        self.addLink(s112, s11)
        self.addLink(s11, s1)

        self.addLink(h121_1, s121)
        self.addLink(h121_2, s121)
        self.addLink(h121_3, s121)
        self.addLink(h122, s122)
        self.addLink(s121, s12)
        self.addLink(s122, s12)
        self.addLink(s12, s1)
        # self.addLink(s12,s2)

        self.addLink(h211_1, s211)
        self.addLink(h211_2, s211)
        self.addLink(h211_3, s211)
        self.addLink(h211_4, s211)
        self.addLink(h212_1, s212)
        self.addLink(h212_2, s212)
        self.addLink(h213_1, s213)
        self.addLink(h213_2, s213)
        self.addLink(h213_3, s213)
        self.addLink(s211, s21)
        self.addLink(s212, s21)
        self.addLink(s213, s21)
        self.addLink(s21, s2)

        self.addLink(h221_1, s221)
        self.addLink(h221_2, s221)
        self.addLink(h222, s222)
        self.addLink(s221, s22)
        self.addLink(s222, s22)
        self.addLink(s22, s2)

        self.addLink(h311_1, s311)
        self.addLink(h311_2, s311)
        self.addLink(h311_3, s311)
        self.addLink(s311, s31)
        self.addLink(s31, s3)

        self.addLink(s1, s2)
        self.addLink(s2, s3)
    # self.addLink(s3,s1)


topos = {'part1': (lambda: sample_topo())}

if __name__ == '__main__':
    t = sample_topo()
    net = Mininet(topo=t, controller=RemoteController)
    c1 = net.addController('c1')
    net.start()
    CLI(net)
    net.stop()